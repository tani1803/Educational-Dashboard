CREATE DATABASE College_Analysis;

USE College_Analysis;

CREATE TABLE Student (
  Student_ID INT PRIMARY KEY,
  Name VARCHAR(50) NOT NULL,
  Department VARCHAR(50) NOT NULL,
  CGPA DECIMAL(3,2)
  CHECK(CGPA BETWEEN 0 AND 10)
);

CREATE TABLE Marks (
  Student_ID INT,
  FOREIGN KEY (Student_ID) REFERENCES Student(Student_ID),
  Course_Name VARCHAR(50) NOT NULL,
  Marks INT CHECK(Marks BETWEEN 0 AND 100),
   PRIMARY KEY (Student_ID,Course_Name)
);


 INSERT INTO Student (Student_ID, Name, Department, CGPA) VALUES
(101, 'Arjun Mehta', 'Computer Science', 9.20),
(102, 'Priya Rai', 'Computer Science', 8.50),
(103, 'Ishan Singh', 'Electrical', 7.80),
(104, 'Ananya Iyer', 'Electrical', 6.50),
(105, 'Rohan Das', 'Mechanical', 9.10),
(106, 'Sana Khan', 'Mechanical', 7.20),
(107, 'Vikram Seth', 'Computer Science', 5.50),
(108, 'Meera Nair', 'Electrical', 8.90);

INSERT INTO Marks (Student_ID, Course_Name, Marks) VALUES
(101, 'DBMS', 95),
(101, 'Algorithms', 92),
(101, 'OS', 88),
(102, 'DBMS', 78),
(102, 'Algorithms', 82),
(102, 'OS', 35),
(107, 'DBMS', 45),
(107, 'Algorithms', 50),
(107, 'OS', 42),
(103, 'Circuits', 85),
(103, 'Signals', 75),
(104, 'Circuits', 40),
(104, 'Signals', 38), 
(108, 'Circuits', 92),
(108, 'Signals', 88),
(105, 'Thermodynamics', 90),
(105, 'Mechanics', 85),
(106, 'Thermodynamics', 60),
(106, 'Mechanics', 65);
