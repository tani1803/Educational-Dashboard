CREATE DATABASE HospitalAssignment;
USE HospitalAssignment;
CREATE TABLE Department (
  DeptID INT PRIMARY KEY,
  DeptName VARCHAR(100),
  FloorNo VARCHAR(10)
);

CREATE TABLE Patient (
  PatientID INT PRIMARY KEY,
  Name VARCHAR(100),
  DOB DATE,
  Gender VARCHAR(10),
  Phone VARCHAR(15),
  City VARCHAR(50)
);

CREATE TABLE Doctor (
  DoctorID INT PRIMARY KEY,
  Name VARCHAR(100),
  Email VARCHAR(100) UNIQUE,
  Phone VARCHAR(15),
  ExperienceYears INT,
  DeptID INT,
  FOREIGN KEY (DeptID) REFERENCES Department(DeptID)
);

CREATE TABLE Appointment (
  AppointmentID INT PRIMARY KEY,
  AppointmentDate DATE,
  StartTime TIME,
  EndTime TIME,
  Status VARCHAR(20) CHECK (Status IN ('Booked', 'Completed', 'Cancelled')), 
  PatientID INT,
  DoctorID INT,
  FOREIGN KEY (PatientID) REFERENCES Patient(PatientID),
  FOREIGN KEY (DoctorID) REFERENCES Doctor(DoctorID),
  UNIQUE (PatientID, DoctorID, AppointmentDate)
);
CREATE TABLE OnlineAppointment (
  AppointmentID INT PRIMARY KEY,
  MeetingLink VARCHAR(255),
  FOREIGN KEY (AppointmentID) REFERENCES Appointment(AppointmentID) ON DELETE CASCADE
);

CREATE TABLE OfflineAppointment (
  AppointmentID INT PRIMARY KEY,
  RoomNumber VARCHAR(20),
  FOREIGN KEY (AppointmentID) REFERENCES Appointment(AppointmentID) ON DELETE CASCADE
);

DELIMITER //

CREATE TRIGGER check_xor_online_insert
BEFORE INSERT ON OnlineAppointment
FOR EACH ROW
BEGIN
    IF EXISTS (SELECT 1 FROM OfflineAppointment WHERE AppointmentID = NEW.AppointmentID) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Error: Appointment cannot be both Online and Offline.';
    END IF;
END //

CREATE TRIGGER check_xor_offline_insert
BEFORE INSERT ON OfflineAppointment
FOR EACH ROW
BEGIN
    IF EXISTS (SELECT 1 FROM OnlineAppointment WHERE AppointmentID = NEW.AppointmentID) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Error: Appointment cannot be both Online and Offline.';
    END IF;
END //

DELIMITER ;

CREATE TABLE Room (
  RoomID INT PRIMARY KEY,
  RoomType VARCHAR(20) CHECK (RoomType IN ('ICU', 'General')),
  DailyCharge DECIMAL(10, 2)
);

CREATE TABLE Admission (
  AdmissionID INT PRIMARY KEY,
  AdmissionDate DATE,
  DischargeDate DATE,
  Reason TEXT,
  PatientID INT NOT NULL,
  PrimaryDoctorID INT NOT NULL,
  FOREIGN KEY (PatientID) REFERENCES Patient(PatientID),
  FOREIGN KEY (PrimaryDoctorID) REFERENCES Doctor(DoctorID)
);

CREATE TABLE RoomStay (
  StayID INT PRIMARY KEY AUTO_INCREMENT,
  AdmissionID INT,
  RoomID INT,
  FromDate DATE,
  ToDate DATE,
  FOREIGN KEY (AdmissionID) REFERENCES Admission(AdmissionID),
  FOREIGN KEY (RoomID) REFERENCES Room(RoomID)
);

DELIMITER //

CREATE TRIGGER check_room_overlap
BEFORE INSERT ON RoomStay
FOR EACH ROW
BEGIN
    DECLARE overlap_count INT;

    SELECT COUNT(*) INTO overlap_count
    FROM RoomStay
    WHERE RoomID = NEW.RoomID
      AND NEW.FromDate < ToDate   
      AND NEW.ToDate > FromDate;   

    IF overlap_count > 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Error: Room is already occupied during these dates.';
    END IF;
END //

DELIMITER ;

CREATE TABLE LabTest (
  TestID INT PRIMARY KEY,
  TestName VARCHAR(100),
  TestCost DECIMAL(10, 2)
);

CREATE TABLE TestOrder (
  OrderID INT PRIMARY KEY,
  OrderDate DATE,
  Status VARCHAR(20) CHECK (Status IN ('Pending', 'Completed')), 
  PatientID INT,
  DoctorID INT,
  FOREIGN KEY (PatientID) REFERENCES Patient(PatientID),
  FOREIGN KEY (DoctorID) REFERENCES Doctor(DoctorID)
);

CREATE TABLE TestOrderDetails (
  OrderID INT,
  TestID INT,
  PRIMARY KEY (OrderID, TestID),
  FOREIGN KEY (OrderID) REFERENCES TestOrder(OrderID),
  FOREIGN KEY (TestID) REFERENCES LabTest(TestID)
);

CREATE TABLE Staff (
  StaffID INT PRIMARY KEY,
  Name VARCHAR(100),
  Role VARCHAR(50),
  Phone VARCHAR(15)
);

CREATE TABLE DutySlot (
  SlotID INT PRIMARY KEY,
  Date DATE,
  StartTime TIME,
  EndTime TIME
);

CREATE TABLE StaffDuty (
  StaffID INT,
  SlotID INT,
  PRIMARY KEY (StaffID, SlotID),
  FOREIGN KEY (StaffID) REFERENCES Staff(StaffID),
  FOREIGN KEY (SlotID) REFERENCES DutySlot(SlotID)
);