# Understanding the Resume Builder App

This guide explains how the Resume Builder app works, covering UI design, PDF generation, and secure file sharing.

## 1. The User Interface (XML)
The UI is built using **Material Design** components.
- **ScrollView**: Essential for forms. It ensures that users on smaller screens can scroll down to see all input fields.
- **TextInputLayout & TextInputEditText**: These provide the "Floating Label" effect. When you click a field, the hint moves up, which is a standard Android UX pattern.
- **Input Types**: We used `android:inputType="textEmailAddress"` or `phone` to ensure the correct keyboard pops up for the user.

## 2. Generating the PDF (`PdfDocument`)
Android provides a built-in `PdfDocument` class. Think of it like a digital piece of paper.
- **PageInfo**: Defines the size (A4 is 595x842 points).
- **Canvas**: This is the most important part. We use `canvas.drawText(text, x, y, paint)` to "paint" words onto the page.
- **Coordinates**: The top-left corner is `(0,0)`. As `y` increases, we move down the page.
- **Lifecycle**: You must `startPage()`, draw your content, `finishPage()`, and finally `writeTo()` a file.

## 3. Storage and Permissions
Modern Android (API 29+) is very strict about privacy.
- **App-Specific Storage**: We save the PDF in `getExternalFilesDir(null)`. 
- **Benefit**: This directory belongs to the app. We **don't need to ask the user for "Storage Permission"** to write files here. When the app is uninstalled, these files are automatically cleaned up.

## 4. Sharing via FileProvider
You cannot simply send a file path to another app (like Gmail) because of security restrictions (FileUriExposedException).
- **FileProvider**: Acts as a "secure gatekeeper." It converts a private file path into a **Content URI** (`content://...`).
- **Granting Permissions**: When we start the Share Intent, we add `FLAG_GRANT_READ_URI_PERMISSION`. This tells Android: "Give the Gmail app temporary permission to read *only* this specific PDF."

## 5. Intent (Sharing)
We use an **Implicit Intent** with `ACTION_SEND`.
- We don't tell the phone "Open Gmail." Instead, we say "I have a PDF, find an app that can share it."
- The **Chooser** (`Intent.createChooser`) allows the user to pick their preferred app.

---
### Student Exercise Ideas:
1. **Customization**: Change the `titlePaint` color to blue.
2. **Logic**: Add a "Clear" button to wipe all text fields.
3. **Advanced**: Try adding an `ImageView` to the layout and draw a profile picture onto the PDF Canvas.
