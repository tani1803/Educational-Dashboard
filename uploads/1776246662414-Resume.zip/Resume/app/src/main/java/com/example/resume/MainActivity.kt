package com.example.resume

import android.content.Intent
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.textfield.TextInputEditText
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

class MainActivity : AppCompatActivity() {

    private lateinit var etName: TextInputEditText
    private lateinit var etEmail: TextInputEditText
    private lateinit var etPhone: TextInputEditText
    private lateinit var etEducation: TextInputEditText
    private lateinit var etExperience: TextInputEditText
    private lateinit var etSkills: TextInputEditText
    private lateinit var btnGenerate: Button
    private lateinit var btnStudyGuide: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        etName = findViewById(R.id.etName)
        etEmail = findViewById(R.id.etEmail)
        etPhone = findViewById(R.id.etPhone)
        etEducation = findViewById(R.id.etEducation)
        etExperience = findViewById(R.id.etExperience)
        etSkills = findViewById(R.id.etSkills)
        btnGenerate = findViewById(R.id.btnGenerate)
        btnStudyGuide = findViewById(R.id.btnStudyGuide)

        btnGenerate.setOnClickListener {
            if (validateInputs()) {
                generateAndSharePdf()
            }
        }

        btnStudyGuide.setOnClickListener {
            generateAndShareStudyGuide()
        }
    }

    private fun validateInputs(): Boolean {
        if (etName.text.isNullOrEmpty() || etEmail.text.isNullOrEmpty()) {
            Toast.makeText(this, "Please enter Name and Email", Toast.LENGTH_SHORT).show()
            return false
        }
        return true
    }

    private fun generateAndSharePdf() {
        val name = etName.text.toString()
        val email = etEmail.text.toString()
        val phone = etPhone.text.toString()
        val education = etEducation.text.toString()
        val experience = etExperience.text.toString()
        val skills = etSkills.text.toString()

        val pdfDocument = PdfDocument()
        val paint = Paint()
        val titlePaint = Paint()

        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
        val page = pdfDocument.startPage(pageInfo)
        val canvas: Canvas = page.canvas

        titlePaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        titlePaint.textSize = 24f
        canvas.drawText("RESUME", 250f, 50f, titlePaint)

        paint.textSize = 14f
        var yPos = 100f

        canvas.drawText("Name: $name", 50f, yPos, paint)
        yPos += 30f
        canvas.drawText("Phone: $phone", 50f, yPos, paint)
        yPos += 30f
        canvas.drawText("Email: $email", 50f, yPos, paint)
        yPos += 50f

        titlePaint.textSize = 18f
        canvas.drawText("Education:", 50f, yPos, titlePaint)
        yPos += 25f
        yPos = drawMultilineText(canvas, education, 50f, yPos, paint) + 30f

        canvas.drawText("Experience:", 50f, yPos, titlePaint)
        yPos += 25f
        yPos = drawMultilineText(canvas, experience, 50f, yPos, paint) + 30f

        canvas.drawText("Skills:", 50f, yPos, titlePaint)
        yPos += 25f
        drawMultilineText(canvas, skills, 50f, yPos, paint)

        pdfDocument.finishPage(page)

        val file = File(getExternalFilesDir(null), "Resume.pdf")
        try {
            pdfDocument.writeTo(FileOutputStream(file))
            sharePdf(file, "Resume - $name", email)
        } catch (e: IOException) {
            Toast.makeText(this, "Error saving PDF", Toast.LENGTH_SHORT).show()
        } finally {
            pdfDocument.close()
        }
    }

    private fun generateAndShareStudyGuide() {
        val pdfDocument = PdfDocument()
        val paint = Paint()
        val titlePaint = Paint()

        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
        val page = pdfDocument.startPage(pageInfo)
        val canvas: Canvas = page.canvas

        titlePaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        titlePaint.textSize = 20f
        canvas.drawText("App Development Study Guide", 50f, 50f, titlePaint)

        paint.textSize = 12f
        var yPos = 80f

        val guideLines = arrayOf(
            "1. Layout (XML): Uses ScrollView for long forms.",
            "2. PDF API: Uses PdfDocument to draw on a Canvas.",
            "3. Storage: Saves files in app-private folder (no permission needed).",
            "4. FileProvider: Securely shares files with other apps.",
            "5. Intents: Uses ACTION_SEND with a selector for Email apps."
        )

        for (line in guideLines) {
            canvas.drawText(line, 50f, yPos, paint)
            yPos += 25f
        }

        pdfDocument.finishPage(page)
        val file = File(getExternalFilesDir(null), "StudyGuide.pdf")
        try {
            pdfDocument.writeTo(FileOutputStream(file))
            sharePdf(file, "Resume Builder Study Guide", "")
        } catch (e: IOException) {
            e.printStackTrace()
        } finally {
            pdfDocument.close()
        }
    }

    private fun drawMultilineText(canvas: Canvas, text: String, x: Float, y: Float, paint: Paint): Float {
        var currentY = y
        if (text.isEmpty()) return currentY
        for (line in text.split("\n")) {
            canvas.drawText(line, x, currentY, paint)
            currentY += 20f
        }
        return currentY
    }

    private fun sharePdf(file: File, subject: String, recipientEmail: String) {
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        
        // Main intent for sharing the PDF
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            if (recipientEmail.isNotEmpty()) {
                putExtra(Intent.EXTRA_EMAIL, arrayOf(recipientEmail))
            }
            putExtra(Intent.EXTRA_SUBJECT, subject)
            putExtra(Intent.EXTRA_TEXT, "Generated via Resume Builder App")
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }

        // Selector intent ensures ONLY email apps are shown
        val selectorIntent = Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("mailto:")
        }
        intent.selector = selectorIntent

        try {
            startActivity(Intent.createChooser(intent, "Send Email..."))
        } catch (e: Exception) {
            // Fallback: if no email app is configured, try general sharing
            val fallbackIntent = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(fallbackIntent, "Share Resume"))
        }
    }
}